# Card Images

These SVG playing card images were generated using:
https://www.me.uk/cards/makeadeck.cgi

Settings used:
- Style: Plain Pip
- Ace style: Large
- Card back: Goodall
